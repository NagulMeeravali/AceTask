package com.kkp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kkp.Dao.DBCon;
import com.kkp.model.AddProduct;

public class DeleteProductController extends HttpServlet
{
	public void service(ServletRequest req,ServletResponse response) throws IOException
	{
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		try {
AddProduct ap=new DBCon().viewProducts();
if(ap!=null)
{
	RequestDispatcher rd=req.getRequestDispatcher("DeleteProduct.jsp");
	rd.forward(req, response);
}
else{
	RequestDispatcher rd=req.getRequestDispatcher("login-error.jsp");
	rd.forward(req, response);
}
	

		}
		catch(Exception e)
		{
			System.out.println(e);
		}


	
	}
/*protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
}
*/		}
