package com.kkp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Date;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kkp.Dao.DBCon;
import com.kkp.model.AddProduct;

public class ProductController extends HttpServlet
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
AddProduct ap=new AddProduct();
ap.setPid(request.getParameter("pid"));
ap.setPname(request.getParameter("pname"));
ap.setPprice(Double.parseDouble(request.getParameter("pprice")));
ap.setPqty(Integer.parseInt(request.getParameter("pqty")));
ap.setTdate(request.getParameter("tdate"));
try {
	int i=new DBCon().addProduct(ap);
	if(i>0)
	{
		RequestDispatcher rd=request.getRequestDispatcher("AddProduct.jsp");
		rd.include(request, response);
		out.print("<body><center><h3><font color=red>Product Details added Successfully</font></h3></center></body>");
	}
	else{
		RequestDispatcher rd=request.getRequestDispatcher("AddProduct.jsp");
		rd.include(request, response);
		out.print("<body><center><h3><font color=red>invalid Details</font></h3></center></body>");
	}
} catch (SQLException e) {
	
	e.printStackTrace();
}
			
	}
}
