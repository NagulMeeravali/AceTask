package com.kkp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;

import com.kkp.Dao.DBCon;
import com.kkp.model.AddProduct;

public class EditProduct extends HttpServlet
{
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
                   String pid=request.getParameter("pid");
                   System.out.println("Pid: "+pid);
                  AddProduct ap;
                 
					try {
						ap=new DBCon().editProduct(pid);
						RequestDispatcher rd=request.getRequestDispatcher("EditProduct.jsp");
						rd.forward(request, response);
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}

}
}
