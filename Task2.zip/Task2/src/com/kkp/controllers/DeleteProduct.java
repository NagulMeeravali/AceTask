package com.kkp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kkp.Dao.DBCon;

public class DeleteProduct extends HttpServlet 
{
	public void service(ServletRequest request, ServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
                   String pid=request.getParameter("pid");
                   System.out.println("Pid: "+pid);
                   try {
					int i=new DBCon().deleteProduct(pid);
					
					if(i>0){
						RequestDispatcher rd=request.getRequestDispatcher("ViewProduct.jsp");
						rd.forward(request, response);
					}
					else{
						RequestDispatcher rd=request.getRequestDispatcher("login-error.jsp");
						rd.forward(request, response);
					}
					
					
				} catch (SQLException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
	}

}
