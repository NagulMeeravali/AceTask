package com.kkp.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.kkp.Dao.DBCon;
import com.kkp.model.RegisterBean;

public class RegisterController extends HttpServlet 
{
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String name=request.getParameter("name");
		String pwd=request.getParameter("pwd");
		String email=request.getParameter("email");
		long mobile=Long.parseLong(request.getParameter("mobile"));
		String city=request.getParameter("city");
		String adr=request.getParameter("adr");
		int pin=Integer.parseInt(request.getParameter("pin"));
		RegisterBean reg=new RegisterBean();
		reg.setName(name);
		reg.setPwd(pwd);
		reg.setEmail(email);
		reg.setContact(mobile);
		reg.setCity(city);
		reg.setAddress(adr);
		reg.setPincode(pin);
		try {
			int i=new DBCon().register(reg);
			if(i>0)
			{
				RequestDispatcher rd=request.getRequestDispatcher("userlogin.jsp");
				rd.forward(request, response);
				
			}
			else
			{
				RequestDispatcher rd=request.getRequestDispatcher("register.jsp");
				rd.include(request, response);
				out.print("<body><center><h3><font color=red>Error in Registration </font></h3></center></body>");
			}
			
		} catch (SQLException e) {
			System.out.println(e);
		}
}
}
