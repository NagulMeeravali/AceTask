package com.kkp.Dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.kkp.model.AddProduct;
import com.kkp.model.RegisterBean;

public class DBCon 
{
	Connection con=null;
	 public DBCon() {
	
			try {
			Class.forName("org.h2.Driver");
		con=DriverManager.getConnection("jdbc:h2:tcp://localhost/~/test","sa","sa");
		} 
		catch (ClassNotFoundException e) 
		{
			
			System.out.println(e);
		} catch (SQLException e) {
			
			System.out.println(e);
		}
		
		}
	public int addProduct(AddProduct obj) throws SQLException
	{
		
		PreparedStatement pstmt=con.prepareStatement("insert into productinfo values(?,?,?,?,?)");
		pstmt.setString(1,obj.getPid());
		pstmt.setString(2, obj.getPname());
		pstmt.setDouble(3,obj.getPprice());
		pstmt.setInt(4,obj.getPqty());
		pstmt.setString(5,obj.getTdate());
		int i=pstmt.executeUpdate();
		return i;
	}
	public  int deleteProduct(String pid) throws SQLException
	{
		Statement stmt=con.createStatement();
		int i=stmt.executeUpdate("delete from productinfo where pid='"+pid+"'");
		return i;
	}
	public  ResultSet viewAllProducts() throws SQLException
	{
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from productinfo");
	return rs;
	}
	public  AddProduct viewProducts() throws SQLException
	{
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from productinfo");
		AddProduct ap=new AddProduct();
		while(rs.next())
		{
			ap.setPid(rs.getString(1));
			ap.setPname(rs.getString(2));
			ap.setPprice(rs.getDouble(3));
			ap.setPqty(rs.getInt(4));
			ap.setTdate(rs.getString(5));
		}
		return ap;
	}
	public ResultSet searchProduct(int pname) throws SQLException
	{
		Statement stmt=con.createStatement();
		ResultSet rs=stmt.executeQuery("select * from productinfo where pid='"+pname+"'");
		return rs;
	}
	public int  register(RegisterBean obj) throws SQLException
	{
		PreparedStatement pstmt=con.prepareStatement("insert into user values(?,?,?,?,?,?,?)");
		pstmt.setString(1, obj.getName());
		pstmt.setString(2,obj.getPwd());
		pstmt.setString(3, obj.getEmail());
		pstmt.setLong(4, obj.getContact());
		pstmt.setString(5, obj.getCity());
		pstmt.setString(6, obj.getAddress());
		pstmt.setInt(7, obj.getPincode());
		int i=pstmt.executeUpdate();
		return i;
	}
    public AddProduct editProduct(String pid) throws SQLException
    {

		Statement stmt=null;
		ResultSet rs=null;
		try {
			stmt = con.createStatement();
		 rs=stmt.executeQuery("select * from productinfo where pid='"+pid+"'");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
		AddProduct ap=new AddProduct();
		while(rs.next())
		{
			ap.setPid(rs.getString(1));
			ap.setPname(rs.getString(2));
			ap.setPprice(rs.getDouble(3));
			ap.setPqty(rs.getInt(4));
			ap.setTdate(rs.getString(5));
		}
		return ap;
    }
    public ResultSet userValidate(String uname,String pwd)
    {
    	Statement stmt=null;
		ResultSet rs=null;
		try {
			stmt = con.createStatement();
		 rs=stmt.executeQuery("select * from user where name='"+uname+"' and password='"+pwd+"'");
		} 
		catch (Exception e) {
			e.printStackTrace();
		}
    	return rs;
    }
}
